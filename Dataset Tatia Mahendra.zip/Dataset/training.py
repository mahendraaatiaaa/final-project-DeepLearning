import os
import sys
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
import tensorflow as tf
from keras.callbacks import EarlyStopping
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras import layers, models

# Verifikasi path ke folder training dan validation
training_path = r'D:\ITS\Computer Engineering\Seventh Semester\Deep Learning for Multimedia\Final Project\Dataset\training'
validation_path = r'D:\ITS\Computer Engineering\Seventh Semester\Deep Learning for Multimedia\Final Project\Dataset\validation'

assert os.path.exists(training_path), f"Error: Training path not found: {training_path}"
assert os.path.exists(validation_path), f"Error: Validation path not found: {validation_path}"

# Membuat ImageDataGenerator untuk training dan validation
train_datagen = ImageDataGenerator(
    rescale=1.0 / 255,  # Normalisasi pixel
    rotation_range=30, 
    width_shift_range=0.2, 
    height_shift_range=0.2,
    shear_range=0.2, 
    zoom_range=0.2, 
    horizontal_flip=True, 
    fill_mode="nearest"
)

validation_datagen = ImageDataGenerator(rescale=1.0 / 255)  # Hanya normalisasi untuk data validasi

# Membaca data training dan validasi dari folder
train_generator = train_datagen.flow_from_directory(
    training_path,
    target_size=(150, 150),  # Ukuran gambar yang ingin digunakan
    batch_size=32,
    class_mode="categorical"  # Untuk multi-class classification
)

validation_generator = validation_datagen.flow_from_directory(
    validation_path,
    target_size=(150, 150),
    batch_size=32,
    class_mode="categorical"
)

# Definisi arsitektur model
model = models.Sequential([
    layers.Conv2D(32, (3, 3), activation="relu", input_shape=(150, 150, 3)),
    layers.BatchNormalization(),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(64, (3, 3), activation="relu"),
    layers.BatchNormalization(),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(128, (3, 3), activation="relu"),
    layers.BatchNormalization(),
    layers.MaxPooling2D((2, 2)),
    layers.Flatten(),
    layers.Dense(128, activation="relu"),
    layers.Dropout(0.2),
    layers.Dense(len(train_generator.class_indices), activation="softmax"),  # Menggunakan jumlah kelas dari generator
])

# Compile model
model.compile(
    optimizer="adam",
    loss="categorical_crossentropy",
    metrics=["accuracy"]
)

# Train the model with data generator
history = model.fit(
    train_generator,
    steps_per_epoch=train_generator.samples // train_generator.batch_size,
    epochs=20,
    validation_data=validation_generator,
    validation_steps=validation_generator.samples // validation_generator.batch_size,
    callbacks=[EarlyStopping(patience=5, restore_best_weights=True)]
)
