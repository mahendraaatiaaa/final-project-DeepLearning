from PIL import Image
import os

# Direktori tempat foto-foto nanas disimpan
folder_path = 'D:\ITS\Computer Engineering\Seventh Semester\Deep Learning for Multimedia\Final Project\Dataset\dataset_mangga'  # Ganti dengan path folder Anda
output_size = (177, 177)  # Ukuran gambar yang diinginkan

# Ambil daftar semua file dalam folder
files = os.listdir(folder_path)

# Loop melalui setiap file untuk resize dan rename
for index, filename in enumerate(files):
    # Cek apakah file memiliki ekstensi gambar yang umum
    if filename.endswith(('.jpg', '.jpeg', '.png')):
        # Path lengkap file lama
        old_path = os.path.join(folder_path, filename)
        
        # Membuka dan mengubah ukuran gambar
        img = Image.open(old_path)
        img_resized = img.resize(output_size)
        
        # Ekstensi file
        ext = filename.split('.')[-1]
        
        # Nama file baru (contoh: nanas1.jpg, nanas2.jpg, ...)
        new_name = f"mangga{index + 1}.{ext}"
        new_path = os.path.join(folder_path, new_name)
        
        # Menyimpan gambar dengan ukuran baru dan nama baru
        img_resized.save(new_path)
        
        # Jika nama file baru berbeda dengan file lama, hapus file lama
        if old_path != new_path:
            os.remove(old_path)

print("Semua gambar berhasil diubah ukurannya dan diganti namanya!")
