const upload = document.getElementById('upload');
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const resultDiv = document.getElementById('result');

upload.addEventListener('change', async (event) => {
    if (!event.target.files.length) return;

    const file = event.target.files[0];
    const img = new Image();
    img.src = URL.createObjectURL(file);

    img.onload = async () => {
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        try {
            const model = await cocoSsd.load();
            const predictions = await model.detect(canvas);

            resultDiv.innerHTML = '';
            predictions.forEach(prediction => {
                const p = document.createElement('p');
                p.innerText = `${prediction.class} - ${Math.round(prediction.score * 100)}%`;
                resultDiv.appendChild(p);
            });
        } catch (error) {
            console.error('Error loading model or making predictions:', error);
            resultDiv.innerHTML = 'Error making predictions';
        } finally {
            URL.revokeObjectURL(img.src);
        }
    };
});