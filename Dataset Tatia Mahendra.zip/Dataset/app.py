from flask import Flask, render_template, request, jsonify
import tensorflow as tf
import numpy as np
from PIL import Image
import io

app = Flask(__name__)

# Load pre-trained SimpleNet2D model
model = tf.keras.models.load_model('SimpleNet2D_model.h5')  # Gantilah dengan path model SimpleNet2D yang sudah dilatih

# Fungsi untuk memproses gambar dan membuat prediksi
def prepare_image(image_bytes):
    image = Image.open(io.BytesIO(image_bytes))
    image = image.resize((224, 224))  # Sesuaikan dengan ukuran input model SimpleNet2D
    image_array = np.array(image) / 255.0
    image_array = np.expand_dims(image_array, axis=0)
    return image_array

# Route untuk homepage
@app.route('/')
def index():
    return render_template('index.html')

# Route untuk menerima gambar dan prediksi
@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"})
    
    image_bytes = file.read()
    image_array = prepare_image(image_bytes)
    
    # Prediksi objek pada gambar
    predictions = model.predict(image_array)
    predicted_class = np.argmax(predictions)
    
    # Misalkan ada mapping nama kelas berdasarkan prediksi (sesuaikan dengan model yang dipakai)
    class_names = ['class1', 'class2', 'class3', 'class4']  # Ganti dengan kelas yang sesuai
    predicted_label = class_names[predicted_class]
    confidence = float(predictions[0][predicted_class])
    
    return jsonify({"label": predicted_label, "confidence": confidence})

if __name__ == '__main__':
    app.run(debug=True)
