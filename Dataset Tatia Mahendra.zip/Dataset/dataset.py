import os
import shutil
from sklearn.model_selection import train_test_split

# Tentukan path folder
real_dataset_path = 'D:/ITS/Computer Engineering/Seventh Semester/Deep Learning for Multimedia/Final Project/Dataset/real dataset'
training_path = 'D:/ITS/Computer Engineering/Seventh Semester/Deep Learning for Multimedia/Final Project/Dataset/training'
validation_path = 'D:/ITS/Computer Engineering/Seventh Semester/Deep Learning for Multimedia/Final Project/Dataset/validation'

# Membuat folder training dan validation jika belum ada
os.makedirs(training_path, exist_ok=True)
os.makedirs(validation_path, exist_ok=True)

# Mendapatkan daftar sub-folder
sub_folders = os.listdir(real_dataset_path)

# Untuk setiap sub-folder
for folder in sub_folders:
    folder_path = os.path.join(real_dataset_path, folder)
    
    if os.path.isdir(folder_path):  # Pastikan hanya sub-folder
        # Ambil semua gambar dari folder tersebut
        images = os.listdir(folder_path)
        
        # Membagi gambar menjadi data training dan validation (80%-20%)
        train_images, val_images = train_test_split(images, test_size=0.2, random_state=42)
        
        # Membuat folder yang sesuai di dalam training dan validation
        train_folder = os.path.join(training_path, folder)
        val_folder = os.path.join(validation_path, folder)
        
        os.makedirs(train_folder, exist_ok=True)
        os.makedirs(val_folder, exist_ok=True)
        
        # Pindahkan gambar ke folder training dan validation
        for image in train_images:
            shutil.copy(os.path.join(folder_path, image), os.path.join(train_folder, image))
        
        for image in val_images:
            shutil.copy(os.path.join(folder_path, image), os.path.join(val_folder, image))
